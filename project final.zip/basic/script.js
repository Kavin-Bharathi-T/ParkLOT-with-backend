function check()
{
    var username= document.getElementById("un").value;
    var password=document.getElementById("pw").value;
    if(username=="admin" && password==000){
        alert ("Login Successfully");
    }
    else{
        alert("Login Unsuccessfull");
    }
}